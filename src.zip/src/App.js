import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import Home from './pages/Home';
import ProductList from './pages/ProductList'

class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <Route path="/" exact component={Home} />
        <Route path="/products" component={ProductList} />
      </BrowserRouter>
    );
  }
}

export default App;
