import React from 'react';

const Footer = () => <p>Copyright &copy;2019 by Alven Maretinus</p>

export default Footer;
