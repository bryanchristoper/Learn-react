import React from 'react'

const Header = () => (
  <div className="header">
    <h1>Hello World</h1>
    <h2>Ini adalah halaman pertama saya</h2>
  </div>
);

export default Header;
